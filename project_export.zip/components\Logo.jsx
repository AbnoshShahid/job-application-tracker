
const Logo = () => {
    return (
        <h2 className='text-2xl font-bold'>
            <span className='text-blue-500'>Job</span>Tracker
        </h2>
    );
};

export default Logo;
